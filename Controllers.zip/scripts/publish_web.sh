cd /home/ubuntu/web
dotnet publish