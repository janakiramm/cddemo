# dn -core
